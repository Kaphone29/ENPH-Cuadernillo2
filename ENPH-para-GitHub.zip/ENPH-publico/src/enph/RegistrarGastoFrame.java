package enph;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.math.BigDecimal;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

/** Caso de uso 01: Registrar gasto diario del hogar. */
public class RegistrarGastoFrame extends JFrame {

    private final int idHogar;
    private boolean cargando = false;

    private final JComboBox<Item> cboVisita = new JComboBox<Item>();
    private final SelectorFecha selectorFecha = new SelectorFecha();
    private java.time.LocalDate inicioCiclo;
    private final java.util.Map<Integer,java.time.LocalDate> fechasVisita = new java.util.HashMap<>();
    private final JLabel lblPeriodo = new JLabel(" ");
    private final JComboBox<Item> cboCategoria = new JComboBox<Item>();
    private final JComboBox<Item> cboProducto = new JComboBox<Item>();
    private final JLabel lblUnidad = new JLabel("-");
    private final JComboBox<Item> cboMiembro = new JComboBox<Item>();
    private final JTextField txtCantidad = new JTextField();
    private final JTextField txtValor = new JTextField();
    // Valores permitidos por el CHECK ck_gasto_forma
    private final JComboBox<String> cboForma = new JComboBox<String>(
            new String[]{"Compra", "Regalo", "Trueque", "Pago en especie", "Produccion propia"});
    private final JTable tabla = Estilo.tabla();
    private final JLabel lblTotal = new JLabel("Total de la jornada: $ 0,00");

    // DOCUMENTACION: Construye los componentes de esta clase, configura su estado inicial y registra los eventos definidos en el constructor.
    public RegistrarGastoFrame(int idHogar, String codigoHogar, int diaCiclo) {
        super("Registrar gasto diario - Hogar " + codigoHogar);
        this.idHogar = idHogar;


        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(900, 790);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(Estilo.encabezado("Registrar gasto diario", "Hogar " + codigoHogar + "  |  Encuestador: " + Sesion.nombre),
                BorderLayout.NORTH);

        // ---- Formulario ----
        JPanel form = new JPanel();
        form.setBorder(BorderFactory.createEmptyBorder(8, 12, 4, 12));
        JPanel fechaPanel = new JPanel(new BorderLayout());
        JButton btnNuevaVisita = new JButton("Cargar / crear visita de la fecha");
        JPanel fechaLinea = new JPanel(new FlowLayout(FlowLayout.LEFT,6,0));
        fechaLinea.add(selectorFecha); fechaLinea.add(btnNuevaVisita);
        fechaPanel.add(fechaLinea,BorderLayout.CENTER); fechaPanel.add(lblPeriodo,BorderLayout.SOUTH);
        Estilo.fila(form, 0, "Fecha del gasto", fechaPanel);
        Estilo.fila(form, 1, "Visitas registradas", cboVisita);

        Estilo.fila(form, 2, "Categoría", cboCategoria);
        Estilo.fila(form, 3, "Producto", cboProducto);
        Estilo.fila(form, 4, "Unidad de medida", lblUnidad);
        Estilo.fila(form, 5, "Miembro", cboMiembro);
        Estilo.fila(form, 6, "Cantidad", txtCantidad);
        Estilo.fila(form, 7, "Valor pagado ($)", txtValor);
        Estilo.fila(form, 8, "Forma de adquisición", cboForma);

        JButton btnGuardar = new JButton("Guardar gasto");
        JPanel pBoton = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pBoton.add(btnGuardar);
        Estilo.fila(form, 9, "", pBoton);
        add(new JScrollPane(form), BorderLayout.CENTER);

        // ---- Gastos de la jornada ----
        JPanel sur = new JPanel(new BorderLayout());
        sur.setBorder(BorderFactory.createEmptyBorder(0, 12, 8, 12));
        sur.add(new JLabel("Gastos registrados en la visita seleccionada"), BorderLayout.NORTH);
        JScrollPane sp = new JScrollPane(tabla);
        sp.setPreferredSize(new java.awt.Dimension(700, 190));
        sur.add(sp, BorderLayout.CENTER);
        sur.add(lblTotal, BorderLayout.SOUTH);
        add(sur, BorderLayout.SOUTH);

        // ---- Eventos ----
        cboCategoria.addActionListener(e -> {
            if (!cargando) {
                cargarProductos();
            }
        });
        cboProducto.addActionListener(e -> {
            if (!cargando) {
                actualizarUnidad();
            }
        });
        cboVisita.addActionListener(e -> {
            if (!cargando) {
                Item visita=(Item)cboVisita.getSelectedItem();
                if(visita!=null && fechasVisita.containsKey(visita.id)) {
                    cargando=true; selectorFecha.setFecha(fechasVisita.get(visita.id)); cargando=false;
                }
                cargarGastos();
            }
        });
        selectorFecha.addChangeListener(e -> {if(!cargando) seleccionarFecha();});
        btnNuevaVisita.addActionListener(e -> crearVisita());
        btnGuardar.addActionListener(e -> guardarGasto());

        cargarCatalogos();
        cargarVisitas(0);
    }

    // DOCUMENTACION: Obtiene el inicio del ciclo, categorias y miembros; agrega la opcion Todo el hogar y carga los productos.
    private void cargarCatalogos() {
        try {
            cargando = true;
            Object fecha=Conexion.valor("SELECT fecha_inicio_ciclo FROM hogar WHERE id_hogar=?",idHogar);
            inicioCiclo=new java.sql.Date(((java.util.Date)fecha).getTime()).toLocalDate();
            java.time.format.DateTimeFormatter fmt=java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
            lblPeriodo.setText("Ciclo del hogar: "+inicioCiclo.format(fmt)+" a "+inicioCiclo.plusDays(13).format(fmt));
            selectorFecha.setFecha(inicioCiclo);
            Conexion.cargarCombo(cboCategoria,
                    "SELECT id_categoria, nombre_categoria FROM categoria ORDER BY id_categoria");
            Conexion.cargarCombo(cboMiembro,
                    "SELECT id_miembro, nombres FROM miembro WHERE id_hogar = ? ORDER BY id_miembro", idHogar);
            cboMiembro.insertItemAt(new Item(0, "Todo el hogar (sin miembro)"), 0);
            cboMiembro.setSelectedIndex(0);
            cargando = false;
            cargarProductos();
        } catch (SQLException ex) {
            cargando = false;
            Conexion.mostrarError(this, ex);
        }
    }

    // DOCUMENTACION: Carga productos de la categoria elegida y su unidad; usa cargando para evitar eventos durante la actualizacion.
    private void cargarProductos() {
        Item cat = (Item) cboCategoria.getSelectedItem();
        if (cat == null) {
            return;
        }
        try {
            cargando = true;
            Conexion.cargarCombo(cboProducto,
                    "SELECT id_producto, nombre_producto, unidad_medida FROM producto "
                    + "WHERE id_categoria = ? ORDER BY nombre_producto", cat.id);
        } catch (SQLException ex) {
            Conexion.mostrarError(this, ex);
        } finally {
            cargando = false;
        }
        actualizarUnidad();
    }

    // DOCUMENTACION: Muestra el dato extra del producto seleccionado como unidad de medida.
    private void actualizarUnidad() {
        Item p = (Item) cboProducto.getSelectedItem();
        lblUnidad.setText(p == null ? "-" : p.extra);
    }

    /** @param diaSeleccionar día a dejar seleccionado (0 = la última visita). */
    // DOCUMENTACION: Recarga las visitas y sus fechas; selecciona el dia solicitado o la ultima visita cuando recibe cero.
    private void cargarVisitas(int diaSeleccionar) {
        try {
            cargando = true;
            DefaultTableModel m = Conexion.consultar(
                    "SELECT id_visita, numero_dia_ciclo, fecha_visita, estado_visita FROM visita "
                    + "WHERE id_hogar = ? ORDER BY numero_dia_ciclo", idHogar);
            cboVisita.removeAllItems();
            fechasVisita.clear();
            int seleccion = -1;
            for (int i = 0; i < m.getRowCount(); i++) {
                int id = ((Number) m.getValueAt(i, 0)).intValue();
                int dia = ((Number) m.getValueAt(i, 1)).intValue();
                fechasVisita.put(id,java.time.LocalDate.parse(String.valueOf(m.getValueAt(i,2)),java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                cboVisita.addItem(new Item(id,
                        "Día " + dia + " - " + m.getValueAt(i, 2) + " (" + m.getValueAt(i, 3) + ")",
                        String.valueOf(dia)));
                if (dia == diaSeleccionar) {
                    seleccion = i;
                }
            }
            if (cboVisita.getItemCount() > 0) {
                cboVisita.setSelectedIndex(seleccion >= 0 ? seleccion : cboVisita.getItemCount() - 1);
                Item actual=(Item)cboVisita.getSelectedItem();
                selectorFecha.setFecha(fechasVisita.get(actual.id));
            }
        } catch (SQLException ex) {
            Conexion.mostrarError(this, ex);
        } finally {
            cargando = false;
        }
        cargarGastos();
    }

    // DOCUMENTACION: Busca la visita de la fecha elegida y actualiza la lista de gastos sin crear registros.
    private void seleccionarFecha() {
        if(inicioCiclo==null)return;
        try {
            java.time.LocalDate fecha=selectorFecha.getFecha();
            cargando=true; cboVisita.setSelectedIndex(-1);
            for(int i=0;i<cboVisita.getItemCount();i++) {
                Item visita=cboVisita.getItemAt(i);
                if(fecha.equals(fechasVisita.get(visita.id))) {cboVisita.setSelectedIndex(i);break;}
            }
        } finally {cargando=false;}
        cargarGastos();
    }
    // DOCUMENTACION: Solicita a VisitaServicio la visita de la fecha y recarga la seleccion del dia correspondiente.
    private void crearVisita() {
        try {
            java.time.LocalDate fecha=selectorFecha.getFecha();
            VisitaServicio.obtenerOCrear(idHogar,fecha);
            cargarVisitas(VisitaServicio.diaDelCiclo(inicioCiclo,fecha));
        } catch(SQLException | IllegalArgumentException ex) {Conexion.mostrarError(this,ex);}
    }

    // DOCUMENTACION: Lista los gastos de la visita seleccionada y calcula su total; limpia la tabla si no hay visita.
    private void cargarGastos() {
        Item v = (Item) cboVisita.getSelectedItem();
        if (v == null) {
            tabla.setModel(new DefaultTableModel());
            lblTotal.setText("Total de la jornada: $ 0,00");
            return;
        }
        try {
            DefaultTableModel m = Conexion.consultar(
                    "SELECT p.nombre_producto, g.cantidad, p.unidad_medida, g.valor_pagado, g.forma_adquisicion "
                    + "FROM gasto g JOIN producto p ON p.id_producto = g.id_producto "
                    + "WHERE g.id_visita = ? ORDER BY g.id_gasto", v.id);
            Estilo.mostrar(tabla, m, "Producto", "Cantidad", "Unidad", "Valor pagado", "Forma de adquisición");
            Object total = Conexion.valor("SELECT NVL(SUM(valor_pagado), 0) FROM gasto WHERE id_visita = ?", v.id);
            lblTotal.setText(String.format("Total de la jornada: $ %,.2f", ((Number) total).doubleValue()));
        } catch (SQLException ex) {
            Conexion.mostrarError(this, ex);
        }
    }

    // DOCUMENTACION: Consulta si el hogar sigue Asignado al usuario de la sesion; avisa y devuelve false si dejo de estar disponible.
    private boolean puedeEditar() throws SQLException {
        int n=((Number)Conexion.valor("SELECT COUNT(*) FROM hogar WHERE id_hogar=? AND id_encuestador_asignado=? AND estado='Asignado'",idHogar,Sesion.id)).intValue();
        if(n!=1) {Conexion.info(this,"El hogar ya no está disponible para registrar información con tu usuario.");return false;}
        return true;
    }

    // DOCUMENTACION: Interpreta coma o punto decimal mediante BigDecimal; devuelve null y avisa si el valor no es numerico o no es mayor que cero.
    private BigDecimal leerPositivo(JTextField campo, String nombre) {
        try {
            BigDecimal n = new BigDecimal(campo.getText().trim().replace(',', '.'));
            if (n.signum() <= 0) {
                JOptionPane.showMessageDialog(this, nombre + " debe ser mayor a cero.");
                return null;
            }
            return n;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, nombre + " debe ser un número válido.");
            return null;
        }
    }

    // DOCUMENTACION: Valida producto, cantidad y valor; verifica el hogar, obtiene o crea la visita e inserta el gasto con miembro opcional.
    private void guardarGasto() {
        Item producto = (Item) cboProducto.getSelectedItem();
        Item miembro = (Item) cboMiembro.getSelectedItem();
        if (producto == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto.");
            return;
        }
        BigDecimal cantidad = leerPositivo(txtCantidad, "La cantidad");
        if (cantidad == null) {
            return;
        }
        BigDecimal valor = leerPositivo(txtValor, "El valor pagado");
        if (valor == null) {
            return;
        }
        Object idMiembro = (miembro == null || miembro.id == 0) ? null : (Object) Integer.valueOf(miembro.id);
        try {
            if(!puedeEditar()) return;
            java.time.LocalDate fecha=selectorFecha.getFecha();
            int idVisita=VisitaServicio.obtenerOCrear(idHogar,fecha);
            Conexion.ejecutar("INSERT INTO gasto (id_visita, id_producto, id_miembro, cantidad, valor_pagado, forma_adquisicion) "
                    + "VALUES (?, ?, ?, ?, ?, ?)",
                    idVisita, producto.id, idMiembro, cantidad, valor, cboForma.getSelectedItem());
            cargarVisitas(VisitaServicio.diaDelCiclo(inicioCiclo,fecha));
            txtCantidad.setText("");
            txtValor.setText("");
            cargarGastos();
        } catch (SQLException | IllegalArgumentException ex) {
            Conexion.mostrarError(this, ex);
        }
    }
}
