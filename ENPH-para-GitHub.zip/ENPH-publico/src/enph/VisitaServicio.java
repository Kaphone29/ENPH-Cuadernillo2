package enph;
import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Resuelve una fecha calendario a una visita única dentro del ciclo de 14 días. */
public final class VisitaServicio {
    // DOCUMENTACION: Calcula la diferencia de dias mas uno; solo acepta posiciones del ciclo entre 1 y 14, ambas incluidas.
    public static int diaDelCiclo(LocalDate inicio,LocalDate fecha) throws SQLException {
        long dia=ChronoUnit.DAYS.between(inicio,fecha)+1;
        if(dia<1||dia>14)throw new SQLException("La fecha está fuera del ciclo del hogar: "+inicio+" a "+inicio.plusDays(13)+". Elige una fecha de ese intervalo.");
        return (int)dia;
    }
    // DOCUMENTACION: Exige Encuestador y bloquea el hogar asignado. Reutiliza la visita del dia o la inserta, actualiza el avance y devuelve su identificador en una transaccion.
    public static int obtenerOCrear(int hogar,LocalDate fecha) throws SQLException {
        if(!"Encuestador".equals(Sesion.rol))throw new SQLException("Solo el encuestador puede registrar visitas.");
        try(Connection c=Conexion.obtener()) {
            c.setAutoCommit(false);
            try {
                int dia;
                try(PreparedStatement p=c.prepareStatement("SELECT fecha_inicio_ciclo,estado,id_encuestador_asignado FROM hogar WHERE id_hogar=? FOR UPDATE")) {
                    p.setInt(1,hogar);try(ResultSet r=p.executeQuery()) {
                        if(!r.next())throw new SQLException("No existe el hogar.");
                        if(!"Asignado".equals(r.getString(2))||r.getInt(3)!=Sesion.id)throw new SQLException("El hogar está cerrado o no está asignado a tu usuario.");
                        dia=diaDelCiclo(r.getDate(1).toLocalDate(),fecha);
                    }
                }
                try(PreparedStatement p=c.prepareStatement("SELECT id_visita FROM visita WHERE id_hogar=? AND numero_dia_ciclo=?")) {
                    p.setInt(1,hogar);p.setInt(2,dia);try(ResultSet r=p.executeQuery()) {if(r.next()){int id=r.getInt(1);c.commit();return id;}}
                }
                try(PreparedStatement p=c.prepareStatement("INSERT INTO visita(id_hogar,id_encuestador,fecha_visita,numero_dia_ciclo,estado_visita) VALUES (?,?,?,?,'Al dia')")) {
                    p.setInt(1,hogar);p.setInt(2,Sesion.id);p.setDate(3,Date.valueOf(fecha));p.setInt(4,dia);p.executeUpdate();
                }
                try(PreparedStatement p=c.prepareStatement("UPDATE hogar SET dia_ciclo_actual=GREATEST(dia_ciclo_actual,?) WHERE id_hogar=?")) {p.setInt(1,dia);p.setInt(2,hogar);p.executeUpdate();}
                int id;
                try(PreparedStatement p=c.prepareStatement("SELECT id_visita FROM visita WHERE id_hogar=? AND numero_dia_ciclo=?")) {p.setInt(1,hogar);p.setInt(2,dia);try(ResultSet r=p.executeQuery()){r.next();id=r.getInt(1);}}
                c.commit();return id;
            }catch(SQLException|RuntimeException ex){c.rollback();throw ex;}
        }
    }
}
