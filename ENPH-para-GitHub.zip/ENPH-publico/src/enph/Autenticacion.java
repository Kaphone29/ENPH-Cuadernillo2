package enph;

import java.sql.*;

/** Detecta el rol con consultas parametrizadas. No acepta marcadores HASH_DEMO. */
public final class Autenticacion {
    public static final class Usuario {
        public final int id;
        public final String nombre, rol;
        Usuario(int id, String nombre, String rol) {
            this.id = id; this.nombre = nombre; this.rol = rol;
        }
    }
    // DOCUMENTACION: Calcula SHA-256 de la clave y consulta los tres roles con parametros. Devuelve null si no coincide y rechaza logins que coincidan en varios roles.
    public static Usuario ingresar(String login, char[] clave) throws SQLException {
        String hash = Sesion.hash(new String(clave));
        String sql = "SELECT id_encuestador id, nombre_completo, 'Encuestador' rol FROM encuestador WHERE encuestador_login=? AND contrasena=? "
            + "UNION ALL SELECT id_supervisor, nombre_completo, 'Supervisor' FROM supervisor WHERE supervisor_login=? AND contrasena=? "
            + "UNION ALL SELECT id_recuentista, nombre_completo, 'Recuentista' FROM recuentista WHERE recuentista_login=? AND contrasena=?";
        try (Connection cn = Conexion.obtener(); PreparedStatement ps = cn.prepareStatement(sql)) {
            for (int i=1; i<=6; i+=2) { ps.setString(i,login); ps.setString(i+1,hash); }
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                Usuario u = new Usuario(rs.getInt(1),rs.getString(2),rs.getString(3));
                if (rs.next()) throw new SQLException("El usuario está duplicado entre roles. Revisa sus credenciales.");
                return u;
            }
        }
    }
}
