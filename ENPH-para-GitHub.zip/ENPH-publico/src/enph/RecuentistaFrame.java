package enph;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.table.DefaultTableModel;

/** Recuentista: registra hogares y gestiona su asignación inicial a un encuestador. */
public class RecuentistaFrame extends JFrame {

    private final JTable tabla = Estilo.tabla();
    private final JTextField txtCodigo = new JTextField();
    private final JTextField txtDireccion = new JTextField();
    private final JSpinner spnFecha = new JSpinner(new SpinnerDateModel());
    private final JComboBox<Item> cboEncuestador = new JComboBox<Item>();

    // DOCUMENTACION: Construye los componentes de esta clase, configura su estado inicial y registra los eventos definidos en el constructor.
    public RecuentistaFrame() {
        super("ENPH - Gestión de hogares");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(960, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(Estilo.encabezado("Gestión de hogares", "Recuentista: " + Sesion.nombre), BorderLayout.NORTH);

        spnFecha.setEditor(new JSpinner.DateEditor(spnFecha, "dd/MM/yyyy"));

        JPanel form = new JPanel();
        form.setBorder(BorderFactory.createTitledBorder("Registrar hogar / asignar encuestador"));
        Estilo.fila(form, 0, "Código del hogar (máx. 20)", txtCodigo);
        Estilo.fila(form, 1, "Dirección (máx. 150)", txtDireccion);
        Estilo.fila(form, 2, "Fecha de inicio del ciclo", spnFecha);
        Estilo.fila(form, 3, "Encuestador", cboEncuestador);

        JButton btnRegistrar = new JButton("Registrar hogar");
        JButton btnAsignar = new JButton("Asignar encuestador al hogar seleccionado");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnSalir = new JButton("Cerrar sesión");
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        botones.add(btnRegistrar);
        botones.add(btnAsignar);
        botones.add(btnActualizar);
        botones.add(btnSalir);
        JButton categorias = new JButton("Catálogo de categorías");
        botones.add(categorias);
        categorias.addActionListener(e -> new CategoriaFrame().setVisible(true));

        JPanel norte = new JPanel(new BorderLayout());
        norte.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));
        norte.add(form, BorderLayout.CENTER);
        norte.add(botones, BorderLayout.SOUTH);

        JPanel centro = new JPanel(new BorderLayout());
        centro.add(norte, BorderLayout.NORTH);
        JPanel pTabla = new JPanel(new BorderLayout());
        pTabla.setBorder(BorderFactory.createEmptyBorder(0, 8, 8, 8));
        pTabla.add(new JScrollPane(tabla), BorderLayout.CENTER);
        centro.add(pTabla, BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);

        btnRegistrar.addActionListener(e -> registrar());
        btnAsignar.addActionListener(e -> asignar());
        btnActualizar.addActionListener(e -> cargar());
        btnSalir.addActionListener(e -> {
            Sesion.cerrar();
            new LoginFrame().setVisible(true);
            dispose();
        });

        try {
            Conexion.cargarCombo(cboEncuestador,
                    "SELECT id_encuestador, nombre_completo FROM encuestador ORDER BY nombre_completo");
            cboEncuestador.insertItemAt(new Item(0, "Sin asignar"), 0);
            cboEncuestador.setSelectedIndex(0);
        } catch (SQLException ex) {
            Conexion.mostrarError(this, ex);
        }
        cargar();
    }

    // DOCUMENTACION: Lista hogares con su estado, fecha inicial y encuestador, incluyendo hogares sin asignacion.
    private void cargar() {
        String sql = "SELECT h.id_hogar, h.codigo_hogar, h.direccion, h.estado, h.dia_ciclo_actual, "
                + "h.fecha_inicio_ciclo, NVL(e.nombre_completo, 'Sin asignar') AS encuestador "
                + "FROM hogar h LEFT JOIN encuestador e ON e.id_encuestador = h.id_encuestador_asignado "
                + "ORDER BY h.id_hogar";
        try {
            DefaultTableModel m = Conexion.consultar(sql);
            Estilo.mostrar(tabla, m, "ID", "Código", "Dirección", "Estado", "Día del ciclo", "Inicio del ciclo", "Encuestador");
        } catch (SQLException ex) {
            Conexion.mostrarError(this, ex);
        }
    }

    // DOCUMENTACION: Valida codigo y direccion e inserta un hogar Pendiente o Asignado, segun el encuestador elegido.
    private void registrar() {
        String codigo = txtCodigo.getText().trim();
        String direccion = txtDireccion.getText().trim();
        if (codigo.isEmpty() || direccion.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El código y la dirección son obligatorios.");
            return;
        }
        if (codigo.length() > 20 || direccion.length() > 150) {
            JOptionPane.showMessageDialog(this, "El código admite hasta 20 caracteres y la dirección hasta 150.");
            return;
        }
        Item enc = (Item) cboEncuestador.getSelectedItem();
        boolean asignado = enc != null && enc.id != 0;
        java.sql.Date fecha = new java.sql.Date(((Date) spnFecha.getValue()).getTime());
        try {
            Conexion.ejecutar("INSERT INTO hogar (id_recuentista, id_encuestador_asignado, codigo_hogar, direccion, "
                    + "estado, dia_ciclo_actual, fecha_inicio_ciclo) VALUES (?, ?, ?, ?, ?, 1, ?)",
                    Sesion.id, asignado ? (Object) Integer.valueOf(enc.id) : null, codigo, direccion,
                    asignado ? "Asignado" : "Pendiente", fecha);
            txtCodigo.setText("");
            txtDireccion.setText("");
            cboEncuestador.setSelectedIndex(0);
            cargar();
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1) {
                JOptionPane.showMessageDialog(this, "Ya existe un hogar con el código " + codigo + ".");
            } else {
                Conexion.mostrarError(this, ex);
            }
        }
    }

    // DOCUMENTACION: Asigna el encuestador seleccionado solo a hogares Pendiente o Asignado que no tengan un caso aprobado.
    private void asignar() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un hogar de la lista.");
            return;
        }
        Item enc = (Item) cboEncuestador.getSelectedItem();
        if (enc == null || enc.id == 0) {
            JOptionPane.showMessageDialog(this, "Elige el encuestador que se asignará.");
            return;
        }
        int idHogar = ((Number) tabla.getValueAt(fila, 0)).intValue();
        try {
            int n = Conexion.ejecutar("UPDATE hogar SET id_encuestador_asignado = ?, estado = 'Asignado' "
                    + "WHERE id_hogar = ? AND estado IN ('Pendiente', 'Asignado') AND NOT EXISTS (SELECT 1 FROM caso c WHERE c.id_hogar=hogar.id_hogar AND c.estado_caso='Aprobado')", enc.id, idHogar);
            if (n == 0) {
                JOptionPane.showMessageDialog(this,
                        "Solo se puede asignar un hogar en estado \"Pendiente\" o \"Asignado\".");
            }
            cargar();
        } catch (SQLException ex) {
            Conexion.mostrarError(this, ex);
        }
    }
}
