package enph;

import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/** Resumen de gastos por forma de adquisición y detalle de la forma seleccionada. */
public class FormaAdquisicionFrame extends JFrame {

    private final int idHogar;
    private final JTable tablaFormas = Estilo.tabla();
    private final JTable tablaDetalle = Estilo.tabla();
    private final JLabel lblDetalle = new JLabel("Detalle: selecciona una forma de adquisición");

    // DOCUMENTACION: Construye los componentes de esta clase, configura su estado inicial y registra los eventos definidos en el constructor.
    public FormaAdquisicionFrame(int idHogar, String codigo) {
        super("Forma de adquisición - Hogar " + codigo);
        this.idHogar = idHogar;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(820, 560);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(Estilo.encabezado("Gastos por forma de adquisición", "Hogar " + codigo), BorderLayout.NORTH);

        JPanel arriba = new JPanel(new BorderLayout());
        arriba.add(new JLabel("Resumen por forma de adquisición"), BorderLayout.NORTH);
        arriba.add(new JScrollPane(tablaFormas), BorderLayout.CENTER);

        JPanel abajo = new JPanel(new BorderLayout());
        abajo.add(lblDetalle, BorderLayout.NORTH);
        abajo.add(new JScrollPane(tablaDetalle), BorderLayout.CENTER);

        JPanel centro = new JPanel(new GridLayout(2, 1, 0, 8));
        centro.setBorder(BorderFactory.createEmptyBorder(8, 10, 10, 10));
        centro.add(arriba);
        centro.add(abajo);
        add(centro, BorderLayout.CENTER);

        tablaFormas.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tablaFormas.getSelectedRow() >= 0) {
                cargarDetalle(String.valueOf(tablaFormas.getValueAt(tablaFormas.getSelectedRow(), 0)));
            }
        });
        cargarFormas();
    }

    // DOCUMENTACION: Agrupa los gastos del hogar por forma de adquisicion y suma registros y valores.
    private void cargarFormas() {
        String sql = "SELECT g.forma_adquisicion, COUNT(g.id_gasto) AS num_registros, SUM(g.valor_pagado) AS total_valor "
                + "FROM gasto g JOIN visita v ON v.id_visita = g.id_visita "
                + "WHERE v.id_hogar = ? GROUP BY g.forma_adquisicion ORDER BY total_valor DESC";
        try {
            DefaultTableModel m = Conexion.consultar(sql, idHogar);
            Estilo.mostrar(tablaFormas, m, "Forma de adquisición", "N.º de registros", "Valor total");
        } catch (SQLException ex) {
            Conexion.mostrarError(this, ex);
        }
    }

    // DOCUMENTACION: Lista los gastos de la forma seleccionada con dia, producto, categoria, cantidad, valor y miembro opcional.
    private void cargarDetalle(String forma) {
        String sql = "SELECT v.numero_dia_ciclo, p.nombre_producto, c.nombre_categoria, g.cantidad, "
                + "p.unidad_medida, g.valor_pagado, NVL(m.nombres, 'Todo el hogar') AS miembro "
                + "FROM gasto g JOIN visita v ON v.id_visita = g.id_visita "
                + "JOIN producto p ON p.id_producto = g.id_producto "
                + "JOIN categoria c ON c.id_categoria = p.id_categoria "
                + "LEFT JOIN miembro m ON m.id_miembro = g.id_miembro "
                + "WHERE v.id_hogar = ? AND g.forma_adquisicion = ? "
                + "ORDER BY v.numero_dia_ciclo, p.nombre_producto";
        try {
            DefaultTableModel m = Conexion.consultar(sql, idHogar, forma);
            Estilo.mostrar(tablaDetalle, m, "Día", "Producto", "Categoría", "Cantidad", "Unidad", "Valor pagado", "Miembro");
            lblDetalle.setText("Detalle de: " + forma);
        } catch (SQLException ex) {
            Conexion.mostrarError(this, ex);
        }
    }
}
