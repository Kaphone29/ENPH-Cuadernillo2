package enph;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

/** Caso de uso 02: Consultar resumen de gastos por hogar (con filtro por rango de días). */
public class ResumenHogarFrame extends JFrame {

    private final int idHogar;
    private final JSpinner spnInicio = new JSpinner(new SpinnerNumberModel(1, 1, 14, 1));
    private final JSpinner spnFin = new JSpinner(new SpinnerNumberModel(14, 1, 14, 1));
    private final JTable tabla = Estilo.tabla();
    private final JLabel lblTotal = new JLabel(" ");

    // DOCUMENTACION: Construye los componentes de esta clase, configura su estado inicial y registra los eventos definidos en el constructor.
    public ResumenHogarFrame(int idHogar, String codigo) {
        super("Resumen de gastos - Hogar " + codigo);
        this.idHogar = idHogar;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(700, 460);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(Estilo.encabezado("Resumen de gastos por hogar", "Hogar " + codigo), BorderLayout.NORTH);

        JPanel centro = new JPanel(new BorderLayout());
        centro.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        JButton btnConsultar = new JButton("Consultar");
        filtro.add(new JLabel("Del día"));
        filtro.add(spnInicio);
        filtro.add(new JLabel("al día"));
        filtro.add(spnFin);
        filtro.add(btnConsultar);
        centro.add(filtro, BorderLayout.NORTH);
        centro.add(new JScrollPane(tabla), BorderLayout.CENTER);
        centro.add(lblTotal, BorderLayout.SOUTH);
        add(centro, BorderLayout.CENTER);

        btnConsultar.addActionListener(e -> cargar());
        cargar();
    }

    // DOCUMENTACION: Valida el rango de dias, agrupa los gastos por categoria y suma registros y valores para el hogar.
    private void cargar() {
        int ini = (Integer) spnInicio.getValue();
        int fin = (Integer) spnFin.getValue();
        if (ini > fin) {
            JOptionPane.showMessageDialog(this, "El día inicial no puede ser mayor al día final.");
            return;
        }
        String sql = "SELECT c.nombre_categoria, COUNT(g.id_gasto) AS num_registros, SUM(g.valor_pagado) AS total_gastado "
                + "FROM visita v JOIN gasto g ON g.id_visita = v.id_visita "
                + "JOIN producto p ON p.id_producto = g.id_producto "
                + "JOIN categoria c ON c.id_categoria = p.id_categoria "
                + "WHERE v.id_hogar = ? AND v.numero_dia_ciclo BETWEEN ? AND ? "
                + "GROUP BY c.nombre_categoria ORDER BY total_gastado DESC";
        try {
            DefaultTableModel m = Conexion.consultar(sql, idHogar, ini, fin);
            Estilo.mostrar(tabla, m, "Categoría", "N.º de registros", "Total gastado");
            double total = 0;
            int registros = 0;
            for (int i = 0; i < m.getRowCount(); i++) {
                registros += ((Number) m.getValueAt(i, 1)).intValue();
                total += ((Number) m.getValueAt(i, 2)).doubleValue();
            }
            lblTotal.setText(String.format("Total gastado: $ %,.2f   |   Registros: %d", total, registros));
        } catch (SQLException ex) {
            Conexion.mostrarError(this, ex);
        }
    }
}
