# Publicar el repositorio en GitHub

## Carpeta para publicar

Usa la carpeta ENPH-publico preparada junto a este proyecto. Incluye fuentes comentadas, archivos de NetBeans y documentacion. No incluye conexion.local.properties, dump, datos de hogares, clases compiladas, configuracion privada de NetBeans ni el controlador Oracle. La plantilla conexion.local.properties.example permite configurar cada equipo sin publicar la contraseña real.

## Pasos sin comandos

1. Entra a tu cuenta en https://github.com.
2. Abre https://github.com/new.
3. Escribe ENPH-Cuadernillo2 como nombre.
4. Marca Public para que el docente pueda verlo.
5. Activa Add a README file y pulsa Create repository.
6. En el repositorio, pulsa Add file > Upload files.
7. Abre ENPH-publico en el Explorador. Arrastra su contenido completo a la pagina de carga, manteniendo las carpetas src, nbproject y docs. No arrastres el ZIP ni la carpeta ENPH local.
8. Escribe como mensaje: Documentacion del proyecto ENPH.
9. Confirma la carga con el boton que muestre GitHub para guardar o proponer los cambios. Si genera una propuesta en una rama nueva, revisala y fusiona la propuesta para que los archivos aparezcan en la rama principal.
10. Comprueba que puedas abrir src/enph/LoginFrame.java y docs/GUIA-FACIL.md en la web.
11. Copia la direccion del navegador. Esa es la URL real que debes entregar.

La direccion tendra la forma https://github.com/TU-USUARIO/ENPH-Cuadernillo2. Ese texto es un ejemplo, no un repositorio creado. El enlace real solo existe cuando se crea y publica en tu cuenta.

## Descargar y usar desde GitHub

1. Abre la URL del repositorio.
2. Pulsa Code > Download ZIP y descomprimelo.
3. Prepara el controlador, la configuracion local y la base como explica README.md.
4. En NetBeans selecciona Archivo > Abrir proyecto y elige la carpeta descomprimida que contiene build.xml y nbproject.
5. Ejecuta el proyecto.

## Fuentes oficiales

- Crear repositorio: https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository
- Cargar archivos: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
