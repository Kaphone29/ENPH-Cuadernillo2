# ENPH Cuadernillo 2

Aplicacion de escritorio para registrar y consultar gastos diarios de hogares urbanos durante un ciclo de 14 dias. Utiliza Java Swing, JDBC y Oracle 10g.

## Abrir en este equipo

1. Abre Apache NetBeans.
2. Pulsa Archivo > Abrir proyecto.
3. Selecciona `C:\Users\USUARIO\Documents\Codex\2026-10-11\ho-2\outputs\ENPH`.
4. Pulsa Abrir proyecto. Puede aparecer como DiseñoProyecto.
5. Haz clic derecho sobre ese proyecto > Ejecutar.

Tambien puedes abrir `Iniciar-ENPH.cmd` con doble clic en este equipo.

## Preparar en otro equipo

1. Instala un JDK compatible con el proyecto (sus propiedades indican Java 26), Apache NetBeans y Oracle con una base disponible.
2. Importa la base del proyecto en tu esquema de Oracle. El repositorio publico no incluye el dump ni los datos de los hogares.
3. Coloca el controlador Oracle compatible en `lib/ojdbc14.jar`. En este equipo esta en `C:\oraclexe\app\oracle\product\10.2.0\server\jdbc\lib\ojdbc14.jar`.
4. Copia `conexion.local.properties.example` y renombra la copia a `conexion.local.properties`, en la raiz del proyecto.
5. Completa `usuario` y `clave` con la cuenta de Oracle donde estan las tablas. Ajusta la URL si tu SID no es XE.
6. Abre el proyecto y ejecutalo. El directorio de trabajo debe ser la raiz del proyecto.

La cuenta Oracle configura la conexion. Los campos de la ventana de ingreso corresponden a una cuenta del operativo guardada en las tablas de roles. Cada equipo necesita su propia configuracion local.

## Documentacion

- [Guia facil de uso](docs/GUIA-FACIL.md)
- [Explicacion del codigo](docs/CODIGO.md)
- [Publicar en GitHub](docs/GITHUB.md)

La documentacion agregada a los archivos Java utiliza comentarios `// DOCUMENTACION:`. No cambia instrucciones, consultas, nombres, reglas, parametros ni comportamiento del codigo base.
